/* Bestanden 1.0 - no user data is sent to a server. */
'use strict';
const PREFIX='bestanden-offline-'+new URL(self.registration.scope).pathname+'-';
const CACHE=PREFIX+'v1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./apple-touch-icon.png','./icon-192.png','./icon-512.png'].map(p=>new URL(p,self.registration.scope).href);
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin||!url.href.startsWith(self.registration.scope))return;
 if(request.mode==='navigate'){
  event.respondWith(fetch(request).then(response=>{
   if(response.ok&&ASSETS.includes(url.origin+url.pathname)){
    const clone=response.clone();
    event.waitUntil(caches.open(CACHE).then(cache=>cache.put(new URL('./index.html',self.registration.scope).href,clone)));
   }
   return response;
  }).catch(()=>caches.match(new URL('./index.html',self.registration.scope).href)));
 }else if(ASSETS.includes(url.origin+url.pathname)){
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request)));
 }
});
